/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ibd2;

/**
 *
 * @author Sergio
 */
public class Params {

    public static int RECORDS_REMOVED;
    public static int RECORDS_ADDED;
    public static int BLOCKS_LOADED;
    public static int BLOCKS_SAVED;

}
